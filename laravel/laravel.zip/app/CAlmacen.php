<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CAlmacen extends Model
{
	  protected $table= 'c_almacen';
    //
}

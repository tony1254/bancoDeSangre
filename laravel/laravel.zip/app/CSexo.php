<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CSexo extends Model
{
	  protected $table= 'c_sexo';
    //
}

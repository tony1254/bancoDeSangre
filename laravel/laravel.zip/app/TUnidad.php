<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TUnidad extends Model
{
	  protected $table= 't_unidad';
    //
}

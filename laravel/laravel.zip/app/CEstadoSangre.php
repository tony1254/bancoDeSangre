<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CEstadoSangre extends Model
{
    //
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TSangre extends Model
{
	  protected $table= 't_sangre';
    //
}

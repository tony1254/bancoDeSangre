<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CEstadoUnidad extends Model
{
	  protected $table= 'c_estadoUnidad';

    //
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TDetalleTransaccion extends Model
{
	  protected $table= 't_detalleTransaccion';
    
}

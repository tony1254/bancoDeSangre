<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TTransaccion extends Model
{
	  protected $table= 't_transaccion';
    //
}

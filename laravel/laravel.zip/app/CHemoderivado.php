<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CHemoderivado extends Model
{
	  protected $table= 'c_hemoderivado';
    //
}

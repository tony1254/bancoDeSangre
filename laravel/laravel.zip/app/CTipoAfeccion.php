<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CTipoAfeccion extends Model
{
	  protected $table= 'c_tipoAfeccion';
    //
}

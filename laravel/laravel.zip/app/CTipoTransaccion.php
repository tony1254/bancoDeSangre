<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CTipoTransaccion extends Model
{
	  protected $table= 'c_tipoTransaccion';
    //
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CGrupoSangre extends Model
{
	  protected $table= 'c_grupoSangre';
    //
}

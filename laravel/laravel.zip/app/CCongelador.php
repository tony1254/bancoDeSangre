<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CCongelador extends Model
{
	  protected $table= 'c_congelador';
    //
}

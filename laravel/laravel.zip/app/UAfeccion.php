<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UAfeccion extends Model
{
	  protected $table= 'u_afeccion';
    //
}
